-- ============================================================
--  Elite Deals USA — database schema (idempotent, safe to re-run)
--  Run once in Supabase → SQL Editor → New Query → Run
-- ============================================================

create extension if not exists pgcrypto;

-- ---------- ORDERS ----------
create table if not exists public.orders (
  id                uuid primary key default gen_random_uuid(),
  order_ref         text,
  customer_name     text not null,
  customer_email    text not null,
  customer_phone    text,
  product_name      text not null,
  product_price     numeric not null,
  quantity          integer default 1,
  delivery_address  text,
  order_date        timestamptz default now(),
  payment_status    text default 'pending',
  whatsapp_contact  text default '+17426660496'
);

-- upgrade existing installs (no data loss)
alter table public.orders add column if not exists order_ref text;

create index if not exists orders_email_idx on public.orders (customer_email);
create index if not exists orders_ref_idx   on public.orders (order_ref);
create index if not exists orders_date_idx  on public.orders (order_date desc);

alter table public.orders enable row level security;

drop policy if exists "orders anon insert" on public.orders;
create policy "orders anon insert"
  on public.orders for insert to anon, authenticated with check (true);

drop policy if exists "orders anon select" on public.orders;
create policy "orders anon select"
  on public.orders for select to anon, authenticated using (true);

-- ---------- NEWSLETTER SUBSCRIBERS ----------
create table if not exists public.subscribers (
  id         uuid primary key default gen_random_uuid(),
  email      text unique not null,
  created_at timestamptz default now()
);

alter table public.subscribers enable row level security;

drop policy if exists "subscribers anon insert" on public.subscribers;
create policy "subscribers anon insert"
  on public.subscribers for insert to anon, authenticated with check (true);
